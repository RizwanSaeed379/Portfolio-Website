// Wait for the DOM to fully load
document.addEventListener("DOMContentLoaded", () => {

    // Smooth Scrolling
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener("click", function (e) {
            e.preventDefault();
            const targetElement = document.querySelector(this.getAttribute("href"));
            if (targetElement) {
                targetElement.scrollIntoView({
                    behavior: "smooth"
                });
            }
        });
    });

    // Dark Mode Toggle
    const darkModeToggle = document.getElementById("toggle-dark-mode");
    const bodyElement = document.body;

    if (localStorage.getItem("theme") === "dark") {
        bodyElement.classList.add("dark-mode");
        darkModeToggle.textContent = "Light Mode";
    }

    darkModeToggle.addEventListener("click", () => {
        bodyElement.classList.toggle("dark-mode");
        darkModeToggle.textContent = bodyElement.classList.contains("dark-mode")
            ? "Light Mode"
            : "Dark Mode";
        localStorage.setItem("theme", bodyElement.classList.contains("dark-mode") ? "dark" : "light");
    });

    // Contact Form Submission Simulation
    const form = document.getElementById("contact-form");
    const formStatus = document.getElementById("form-status");

    if (form) {
        form.addEventListener("submit", function (e) {
            e.preventDefault();
            formStatus.style.color = "#1d3557";
            formStatus.textContent = "Sending...";
            setTimeout(() => {
                formStatus.textContent = "Message sent successfully!";
                form.reset();
                setTimeout(() => {
                    formStatus.textContent = "";
                }, 3000);
            }, 1500);
        });
    }

    // Scroll Animation (Fade-In)
    const animatedSections = document.querySelectorAll("section");

    const observerOptions = {
        threshold: 0.1
    };

    const revealOnScroll = (entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = "1";
                entry.target.style.transform = "translateY(0)";
                entry.target.style.transition = "all 0.8s ease";
                observer.unobserve(entry.target); // Only animate once
            }
        });
    };

    const observer = new IntersectionObserver(revealOnScroll, observerOptions);

    animatedSections.forEach(section => {
        section.style.opacity = "0";
        section.style.transform = "translateY(40px)";
        observer.observe(section);
    });
});
